<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trocar Senha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/cadastro_login.css">
    <link rel="shortcut icon" type="imagex/png" href="../assets/logo-cuted.jpeg">
</head>

<body style="background-image:url('../assets/background.jpeg'); height: 300px;">
    <div class="container">
        <!--Inicio do container -->
        <div>
            <div class="card" style="background-color:#f55145; color:#fff; font-size:20px; margin-top: -40px">
                <!--Alterar a cor do bakcground do form-->
                <div class=" text-white" style="background-color: #f55145; outline:none; text-align:center;">
                    <!--Cabeçalho do FORM-->
                    <svg xmlns="http://www.w3.org/2000/svg" width="110" height="110" fill="#fff" class="bi bi-person img" viewBox="0 0 16 16">
                        <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                    </svg>
                </div><!-- FIM do Cabeçalho do FORM-->

                <div class="card-body">
                    <!-- Inicio do Body do FORM-->
                    <form method="POST" action="recupera_senha_back.php">
                        <!-- Início do FORM-->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- INICIO Container field Nome-->
                                <label for="inputNome" class="form-label" style="padding-left:115px;">E-mail</label>
                                <input type="text" name="mail" id="inputNome" class="form-control" placeholder="E-mail do usuário" required>
                            </div>
                            <!--FIM Container field Nome-->
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <!-- INICIO Container field Senha-->
                                <label for="inputSenha" class="form-label" style="padding-left:95px; padding-top: 15px;">Nova senha</label>
                                <input type="password" name="senha" id="inputSenha" class="form-control" placeholder="Digite uma nova senha" required>
                            </div>
                            <!--FIM Container field Senha-->
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <!-- INICIO Container Confirma Senha-->
                                <label for="inputSenha" class="form-label" style="padding-left:55px; padding-top: 15px;">Confirmar Nova senha</label>
                                <input type="password" name="confirmSenha" id="inputSenha" class="form-control" placeholder="Digite novamente a nova senha" required>
                            </div>
                            <!--FIM Container field Senha-->
                        </div>

                        <br>

                        <input type="submit" value="Redefinir senha" class="btn" style="background-color: #fff; color:#f55145; width:100%">
                        <a href="../index.php" style="text-decoration: none;" class="text-white btn btn-dark form-control mt-3">Voltar</a>
                    </form>
                    <br>
           

                </div><!-- FIM do FORM-->
            </div><!-- FIM do Body do FORM-->
        </div>
    </div>
    <!--Fim Container-->