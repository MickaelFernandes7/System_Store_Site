<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Adicionar Produto</title>
</head>

<body style="background-image:url('../assets/background.jpeg'); height: 300px;">

    <?php
    //include do script de conexao do banco de dados
    include "../model/connect.php";

    // Tabela - tbl_compras
    
    // resgatar as informacoes atraves do metodo Post, e salvar em variaveis
    $nomeVenda = $_POST['nomeProdutoVendas'];
    $precoVenda = $_POST['precoVendas'];
    $quantidadeVenda = $_POST['quantidadeVendas'];
    $idEstoque = $_POST['idEstoque'];
    $idProduto = $_POST['idProduto'];
    $dataVenda = $_POST['data'];


    session_start();

    $tipo = $_SESSION['tipo'];

    //query sql - insert
    $sql = "INSERT INTO tbl_vendas(
    nome_produto_vendas, 
    quantidade_produto_vendas,
    preco_produto_vendas, 
    id_estoque,
    id_produto,
    data_venda
    ) VALUES(
        '$nomeVenda',
        '$quantidadeVenda',
        '$precoVenda',
        '$idEstoque',
        '$idProduto',
        '$dataVenda'
    )";

    //insert no banco de dados
    $result = $conexao->query($sql);

    echo "<br>";

    // testar se o cadastro foi feito com sucesso
    if ($result && $tipo === '1') {
        echo "<script> alert('Venda Cadastrada com sucesso!');window.location='../vendas.php'</script>";
    } elseif ($result && $tipo === '2' ) {
        echo "<script> alert('Venda Cadastrada com sucesso!');window.location='../vendas2.php'</script>";
    } else {
        echo "<div style='text-align:center'><h2>Erro ao inserir os dados</h2></div>" . $conexao->error;
    }

    //encerrar conexão
    $conexao->close();
    ?>
</body>

</html>