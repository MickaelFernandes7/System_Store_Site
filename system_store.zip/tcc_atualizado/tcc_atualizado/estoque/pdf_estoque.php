<?php

require_once '../vendor/autoload.php';

use Dompdf\Dompdf;

include "../model/connect.php";

$sql = "SELECT * FROM tbl_estoque";

$result = $conexao->query($sql); 


$html = '<h1 style="background-color: #f55145; color:#fff; text-align:center; font-family: Arial, Helvetica, sans-serif;">Relatorio de Estoque - System Store</h1>';
$html .= '<table border=1 width=100% style="background-color: #f55145; color:#fff; font-weight: bold;">';
$html .= '<thead>';
$html .= '<tr>';
$html .= '<td>Id Estoque</td>';
$html .= '<td>Nome Produto</td>';
$html .= '<td>Quantidade Produto</td>';
$html .= '<td>Preço Produto</td>';
$html .= '<td>Id Compra</td>';
$html .= '<td>Descrição Produto</td>';
$html .= '</tr>';
$html .= '</thead>';
           
          
while ($linha = $result->fetch_array()) {
    $html .= '<tbody>';
    $html .= '<tr>';
    $html .= '<td>' . $idCompra = $linha['id_compras'] .'</td> ';
    $html .= '<td>' . $nomeProd = $linha[1] .'</td> ';
    $html .= '<td>' . $qtdeProd = $linha[2] .'</td> ';
    $html .= '<td>' . $precoProd = $linha[3] .'</td> ';
    $html .= '<td>' . $idCompra = $linha[4] .'</td> ';
    $html .= '<td>' . $descEstoque = $linha[5] .'</td>';
}

$html .= '</table';

$dompdf = new Dompdf;

$dompdf->loadHtml('' . $html);

$dompdf-> setPaper('A4', 'portrait');

$dompdf->render();

$dompdf->stream('relatorio.pdf', array('Attachment' => false));
