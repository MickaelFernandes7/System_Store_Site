<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
</head>

<body style="background-image:url('../assets/background.jpeg'); height:100%;">

    <?php
    //include do script de conexao do banco de dados
    include "../model/connect.php";

    // Tabela - tbl_compras

    // resgatar as informacoes atraves do metodo Post, e salvar em variaveis
    $id = $_POST['id'];
    $nomeProd = $_POST['nomeProduto'];
    $precoProd = $_POST['preco'];
    $quantidadeProd = $_POST['quantidade'];
    $dataProd = $_POST['data'];

    session_start();

    $tipo = $_SESSION['tipo'];

    //query sql - update

    $sql = "UPDATE tbl_compras
        SET id_compras = '$id',
        nome_produto_compra = '$nomeProd',
        quantidade_produto_compra = '$quantidadeProd',
        preco_produto_compra = '$precoProd',
        data_compra = '$dataProd'
        WHERE id_compras = '$id'";

    $result = $conexao->query($sql);

    echo "<br>";

    // testar se o cadastro foi feito com sucesso
    if ($result && $tipo === '1') {
        echo "<script> alert('Dados atualizados com sucesso!');window.location='../compras.php'</script>";
    } elseif ($result && $tipo === '2') {
        echo "<script> alert('Dados atualizados com sucesso!');window.location='../compras2.php'</script>";
    } else {
        echo "<div style='text-align:center'><h2>Erro ao atualizar os dados do produto, conferir se o identificador do produto está correto.</h2></div>";
    }

    //encerrar conexão
    $conexao->close();
    ?>
</body>

</html>