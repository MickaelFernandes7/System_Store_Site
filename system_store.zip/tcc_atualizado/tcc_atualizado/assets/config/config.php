<?php
$hostname= "localhost";
$username = "root";
$password = "M24052002";
$database = "db_loja";
?>