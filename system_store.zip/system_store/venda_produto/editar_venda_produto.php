<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
</head>

<body style="background-image:url('../assets/background.jpeg'); height:100%;">

    <?php
    //include do script de conexao do banco de dados
    include "../model/connect.php";

    // Tabela - tbl_compras

    // resgatar as informacoes atraves do metodo Post, e salvar em variaveis
    $idVenda = $_POST['idVenda'];
    $idProduto = $_POST['idProduto'];
    $precoVenda = $_POST['precoVendas'];
    $quantidadeVenda = $_POST['quantidadeVendas'];
    
    session_start();

    $tipo = $_SESSION['tipo'];

    //query sql - update

    $sql = "UPDATE tbl_venda_produto
        SET id_vendas = '$idVenda',
        id_produto = '$idProduto',
        preco_vendas_produto = '$precoVenda',
        quantidade_vendas_produto = '$quantidadeVenda'
        WHERE id_vendas = '$idVenda'";

    $result = $conexao->query($sql);

    echo "<br>";

    // testar se o cadastro foi feito com sucesso
    if ($result && $tipo === '1') {
        echo "<script> alert('Dados atualizados com sucesso!');window.location='../vendas_produtos.php'</script>";
    } elseif ($result && $tipo === '2') {
        echo "<script> alert('Dados atualizados com sucesso!');window.location='../vendas_produtos2.php'</script>";
    } else {
        echo "<div style='text-align:center'><h2>Erro ao atualizar os dados do produto, conferir se o identificador do produto está correto.</h2></div>";
    }

    //encerrar conexão
    $conexao->close();
    ?>
</body>

</html>