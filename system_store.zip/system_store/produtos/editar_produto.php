<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
</head>

<body style="background-image:url('../assets/background.jpeg'); height:100%;">

    <?php
    //include do script de conexao do banco de dados
    include "../model/connect.php";

    // Tabela - tbl_produto

    // resgatar as informacoes atraves do metodo Post, e salvar em variaveis
    $id = $_POST['id'];
    $nomeProd = $_POST['produto'];
    $precoProd = $_POST['preco'];
    $descProd = $_POST['descricao'];
    $idEstoque = $_POST['idEstoque'];

    session_start();

    $tipo = $_SESSION['tipo'];

    //query sql - update

    $sql = "UPDATE tbl_produto
        SET id_produto = '$id',
        nome_produto = '$nomeProd',
        preco_produto = '$precoProd',
        descricao_produto = '$descProd',
        id_estoque = '$idEstoque'
        WHERE id_produto = '$id'";

    $result = $conexao->query($sql);

    echo "<br>";

    // testar se o produto foi atualizado com sucesso
    if ($result && $tipo === '1') {
        echo "<script> alert('Dados atualizados com sucesso!');window.location='../produtos.php'</script>";
    } elseif($result && $tipo === '2') {
        echo "<script> alert('Dados atualizados com sucesso!');window.location='../produtos2.php'</script>";
    } else {
        echo "<div style='text-align:center'><h2>Erro ao atualizar os dados do produto, conferir se o identificador do produto está correto.</h2></div>".$conexao->error;
    }

    //encerrar conexão
    $conexao->close();
    ?>
</body>

</html>