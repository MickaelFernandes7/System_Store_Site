<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Excluir Produto</title>
</head>

<body style="background-image:url('../assets/background.jpeg'); height:100%;">
    <?php

    //include do script de conexao do banco de dados
    include "../model/connect.php";

    // resgatar as informacoes atraves do metodo Post, e salvar em variaveis
    $nomeProd = $_POST['produto'];

    //query sql - delete
    $sql = "DELETE FROM tbl_produto WHERE nome_produto = '$nomeProd'";

    $result = $conexao->query($sql);

    echo "<br>";

       // testar se o produto foi excluído com sucesso
       if ($result) {
        echo "<script> alert('Produto deletado com sucesso!');window.location='../produtos.php'</script>";
    } else {
        echo "<div style='text-align:center'><h2>Erro ao inserir os dados</h2></div>" . $conexao->error;
    }

    //encerrar conexão
    $conexao->close();
    ?>

</body>

</html>