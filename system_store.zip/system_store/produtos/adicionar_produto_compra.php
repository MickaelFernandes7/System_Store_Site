<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Adicionar Produto</title>
</head>

<body style="background-image:url('../assets/background.jpeg'); height: 300px;">

    <?php
    //include do script de conexao do banco de dados
    include "../model/connect.php";

    // resgatar as informacoes atraves do metodo Post, e salvar em variaveis
    $nomeProd = $_POST['produto'];
    $precoProd = $_POST['preco'];
    $desc = $_POST['descricao'];
    $idEstoque = $_POST['idEstoque'];

    session_start();

    $tipo = $_SESSION['tipo'];


    //query sql - insert
    $sql = "INSERT INTO tbl_produto(
    nome_produto, 
    preco_produto, 
    descricao_produto,
    id_estoque
    ) VALUES(
        '$nomeProd',
        '$precoProd',
        '$desc',
        '$idEstoque'
    )";


    //insert no banco de dados
    $result = $conexao->query($sql);

    echo "<br>";

      // testar se o produto foi cadastrado com sucesso
      if ($result && $tipo === '1') {
        echo "<script> alert('Produto Cadastrado com sucesso!');window.location='../produtos.php'</script>";
    } elseif($result && $tipo === '2') {
        echo "<script> alert('Produto Cadastrado com sucesso!');window.location='../produtos2.php'</script>";
    } else {
        echo "<div style='text-align:center'><h2>Erro ao inserir os dados</h2></div>" . $conexao->error;
    }

    //encerrar conexão
    $conexao->close();
    ?>
</body>
</html>