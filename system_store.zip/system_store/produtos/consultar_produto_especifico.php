<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Consulta do Produto</title>
    <link rel="stylesheet" href="../css/tables.css">
</head>

<body style="background-image:url('../assets/background.jpeg');">

    <div class="container w-100" style="border: solid 1px #fff; background-color:#f55145;">
        <div class="row">
            <div class="col-12 d-flex justify-content-around mb-2">
                <h3 class="text-light fs-5 mt-2">Consulta do Produto</h3>

                <a href="pdf_produtos.php" target="_blank" style="text-decoration: none;">
                    <button class="btn btn-outline-light mt-2 d-md-block d-none d-sm-none">Gerar Pdf</button>
                    <button class="btn btn-outline-light d-md-none mt-2 d-sm-block">PDF</button>
                </a>

                <a href="../produtos.php">
                    <button class="btn btn-outline-light mt-2 ">Voltar</button>
                </a>
            </div>
        </div>

        <div class="row">
            <!--Table-->
            <table class="table-responsive-md table-bordered text-center" style="background-color: #f55145; color:#fff;">

                <thead>
                    <tr class="text-light">
                        <th>ID Produto</th>
                        <th>Nome Produto</th>
                        <th>Preço Produto</th>
                        <th>Descrição Produto</th>
                        <th>ID Estoque</th>
                    </tr>
                </thead>

                <?php

                include "../model/connect.php";

                $nome = $_POST['nomeProduto'];

                //query select
                $sql = "SELECT * FROM tbl_produto WHERE nome_produto= '$nome'";

                // buscar no banco de dados por meio da query select
                // para isso usamos o objeto de conexão e o método query()
                $result = $conexao->query($sql); // orientado a objetos utilizando obj $result

                // montar a lista na tabela
                // enquanto o fetch array possui registros ele retorna TRUE e quando ele termina, retorna FALSE
                // while ($linha = mysqli_fetch_array($result)) { // mysqli_fetch_array() procedural}
                while ($linha = $result->fetch_array()) {
                    $idCompra = $linha['id_produto'];
                    $nomeProd = $linha[1];
                    $precoProd = $linha[2];
                    $descProd = $linha[3];
                    $idEstoque = $linha[4];

                    // montar a tabela
                    $html = <<<HTML
            <tbody>
                <tr>
                    <td>$idCompra</td>
                    <td>$nomeProd</td>
                    <td>$precoProd</td>
                    <td>$descProd</td>
                    <td>$idEstoque</td>
                </tr>
HTML;
                    echo $html;
                } // fim do while

                // apagar o obj
                $result->close();

                // encerrar a conexão
                $conexao->close();
                ?>

            </table>
        </div>
    </div>
</body>