<?php

require_once '../vendor/autoload.php';

use Dompdf\Dompdf;

include "../model/connect.php";

$sql = "SELECT * FROM tbl_produto";

$result = $conexao->query($sql); 


$html = '<h1 style="background-color: #f55145; color:#fff; text-align:center; font-family: Arial, Helvetica, sans-serif;">Relatorio de Produtos - System Store</h1>';
$html .= '<table border=1 width=100% style="background-color: #f55145; color:#fff; font-weight: bold;">';
$html .= '<thead>';
$html .= '<tr>';
$html .= '<td>Id Produto</td>';
$html .= '<td>Nome Produto</td>';
$html .= '<td>Preço Produto</td>';
$html .= '<td>Descrição Produto</td>';
$html .= '<td>Id estoque</td>';
$html .= '</tr>';
$html .= '</thead>';
           
          
while ($linha = $result->fetch_array()) {
    $html .= '<tbody>';
    $html .= '<tr>';
    $html .= '<td>' . $idProd = $linha['id_produto'] .'</td> ';
    $html .= '<td>' . $nomeProd = $linha[1] .'</td> ';
    $html .= '<td>' . $precoProd = $linha[2] .'</td> ';
    $html .= '<td>' . $descProd = $linha[3] .'</td> ';
    $html .= '<td>' . $idEstoque = $linha[4] .'</td> ';
}

$html .= '</table';

$dompdf = new Dompdf;

$dompdf->loadHtml('' . $html);

$dompdf-> setPaper('A4', 'portrait');

$dompdf->render();

$dompdf->stream('relatorio.pdf', array('Attachment' => false));
