<?php
$hostname= "localhost";
$username = "root";
$password = "";
$database = "db_loja";
?>