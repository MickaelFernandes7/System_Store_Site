<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos Administrador</title>
    <link rel="stylesheet" href="css/modals.css"> 
    <link rel="shortcut icon" type="imagex/png" href="assets/logo-cuted.jpeg">
</head>

<body>

    <?php
    session_start();
    ?>

    <?php
    //testar se o usuario está logado

    //verificar se existe uma sessão aberta no server
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    //proteger caso o usúario tente acessar a página do adm, e vice-versa
    if($_SESSION['tipo'] != 1){
        session_destroy();
        header("location:index.php");
    }

    // testar se o usuario está logado ou não
    if (isset($_SESSION['nome'])) {
    } else {
        // apagar a variavel de sessão
        unset($_SESSION['nome']);
        header("Location: index.php");
    }

    ?>

    <main>
        <header>
            <div class="container">
                <!--Container Icone e Texto-->
                <div class="row">
                    <!--Linha da Div-->
                    <div class="col">
                        <!--Coluna da Div-->
                        <!--Icone-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130" fill="#fff" class="bi bi-box-seam icon" viewBox="0 0 16 16">
                            <path d="M8.186 1.113a.5.5 0 0 0-.372 0L1.846 3.5l2.404.961L10.404 2l-2.218-.887zm3.564 1.426L5.596 5 8 5.961 14.154 3.5l-2.404-.961zm3.25 1.7-6.5 2.6v7.922l6.5-2.6V4.24zM7.5 14.762V6.838L1 4.239v7.923l6.5 2.6zM7.443.184a1.5 1.5 0 0 1 1.114 0l7.129 2.852A.5.5 0 0 1 16 3.5v8.662a1 1 0 0 1-.629.928l-7.185 2.874a.5.5 0 0 1-.372 0L.63 13.09a1 1 0 0 1-.63-.928V3.5a.5.5 0 0 1 .314-.464L7.443.184z" />
                        </svg>
                    </div>
                    <!--Fim Coluna da Div-->
                </div>
                <!--Fim Linha da Div-->

                <div class="row">
                    <!--Linha da Div-->
                    <div class="col">
                        <!--Coluna da Div-->

                        <h2 class="title">Produtos</h2>

                        <br>

                        <p class="text">Adicione os produtos que a loja trabalha.</p>

                        <p class="text">Os produtos são adicionados, pelo
                            nome do produto, seu valor, e sua descrição.</p>

                        <p class="text">Os produtos podem ser, adicionados, consultados, modificados, e deletados de
                            acordo
                            com
                            a necessidade.</p>
                    </div>
                </div>
                <!--Fim Coluna da Div-->

                <div class="row">
                    <div class="col">
                        <a href="main.php">
                            <svg style="margin-top: 25px; margin-right:10px;" xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="#fff" class="bi bi-x-lg" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M13.854 2.146a.5.5 0 0 1 0 .708l-11 11a.5.5 0 0 1-.708-.708l11-11a.5.5 0 0 1 .708 0Z" />
                                <path fill-rule="evenodd" d="M2.146 2.146a.5.5 0 0 0 0 .708l11 11a.5.5 0 0 0 .708-.708l-11-11a.5.5 0 0 0-.708 0Z" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <!--Fim Linha da Div-->
        </header>

        <section>
            <!--CARDS-->
            <a href="#" onclick="Modal.openAdicionar()">
                <!--Link Modal Adicionar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Adicionar-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-plus-circle-fill" viewBox="0 0 16 16">
                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z" />
                        </svg>
                    </div>
                    <!--Fim do Div da Imagem-->

                    <div class="card-title-content">
                        <!--Div Título-->
                        <p class="card-title">Adicionar</p>
                    </div>
                    <!--Fim Título-->
                </div>
                <!--Fim do Card Adicionar-->
            </a>
            <!--Fim Link Modal Adicionar-->

            <a href="#" onclick="Modal.openConsultar()">
                <!--Link Modal Consultar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Consultar-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-eye-fill" viewBox="0 0 16 16">
                            <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z" />
                            <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z" />
                        </svg>
                        <!--Fim Div da Imagem-->
                    </div>

                    <div class="card-title-content">
                        <!--Div Título Consultar-->
                        <p class="card-title">Consultar</p>
                    </div>
                    <!--Fim Div Título Consultar-->
                </div>
                <!--Fim do Card Consultar-->
            </a>
            <!--Fim Link Modal Consultar-->

            <a href="#" onclick="Modal.openEditar()">
                <!--Link Modal Editar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Editar-->
                    <div class="img-content">
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-pencil-square" viewBox="0 0 16 16">
                            <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                        </svg>
                    </div>
                    <div class="card-title-content">
                        <!--Início do Título Editar-->
                        <p class="card-title">Editar</p>
                    </div>
                    <!--Fim do Título Editar-->
                </div>
                <!--Fim do Card Editar-->
            </a>
            <!--Fim Link Modal Editar-->

            <a href="#" onclick="Modal.openDeletar()">
                <!--Link Modal Deletar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Deletar-->
                    <div class="img-content">
                        <!--Div Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-trash-fill" viewBox="0 0 16 16">
                            <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z" />
                        </svg>
                    </div>
                    <!--Fim Div Imagem-->

                    <div class="card-title-content">
                        <!--Início do Título Deletar-->
                        <p class="card-title">Deletar</p>
                    </div>
                    <!--Fim do Título Deletar-->
                </div>
                <!--Fim do Card Deletar-->
            </a><!-- Link Modal Deletar-->

            <!--CARDS-->
        </section>
    </main>

    <div class="modal-overlay">
        <!--Container do Modal Adicionar-->
        <div class="modal">
            <!--Modal-->
            <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Novo Produto</h2>

            <!--Titulo Modal-->
            <form method="POST" action="produtos/adicionar_produto_compra.php" id="form">
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="produto" id="produto" placeholder="Nome do Produto" required>
                </div>

                <div class="input-group">
                    <!--Campo Preço-->
                    <input type="number" name="preco" id="preco" placeholder="Preço do Produto" required>
                </div>

                <div class="input-group">
                    <!--Campo Descrição-->
                    <input type="text" name="descricao" id="descricao" placeholder="Descrição do Produto" minlength="10" maxlength="500" required>
                </div>

                <div class="input-group">
                    <!--Campo Id estoque-->
                    <input type="number" name="idEstoque" id="idEstoque" placeholder="ID do estoque"  required>
                </div>


                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeAdicionar()">Cancelar</a>
                    <input type="submit" class="submit" value="Inserir">
                </div>
            </form>
            <!--Fim Formulário Modal-->
        </div>
        <!--Fim Corpo Modal-->
    </div>
    <!--Fim Container Modal Adicionar-->

    <div class="modal-overlay modal-overlay-consultar">
        <!--Container do Modal Consultar-->
        <div class="modal">
            <!--Modal-->
            <div class="modal-title">
                <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Consultar Produtos</h2>
                <br>
                <a href="produtos/consultar_produto.php" style="color:#f55145; width:48%; font-size:14px; margin:5px 0 0 15px;">Consultar todos os Produtos</a>
            </div>
            <!--Titulo Modal-->
            <form method="POST" action="produtos/consultar_produto_especifico.php" id="form">
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="nomeProduto" id="nomeProduto" placeholder="Nome do Produto" required>
                </div>

                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeConsultar()">Cancelar</a>
                    <input type="submit" class="submit" value="Consultar">
                </div>

            </form>
            <!--Fim Formulário Modal-->
        </div>
        <!--Fim Corpo Modal-->
    </div>
    <!--Fim Container Modal Consultar-->

    <div class="modal-overlay modal-overlay-editar">
        <!--Container do Modal Editar-->
        <div class="modal">
            <!--Modal-->
            <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Editar Produto</h2>
            <!--Titulo Modal-->
            <form method="POST" action="produtos/editar_produto.php" id="form">
                <!--Formulário Modal-->

                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="id" id="id" placeholder="ID do Produto" required>
                </div>

                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="produto" id="produto" placeholder="Novo Nome do Produto" required>
                </div>

                <div class="input-group">
                    <!--Campo Preço-->
                    <input type="number" name="preco" id="preco" placeholder="Novo Preço do Produto" required>
                </div>

                <div class="input-group">
                    <!--Campo Descrição-->
                    <input type="text" name="descricao" id="descricao" placeholder="Descrição do Produto" minlength="5" maxlength="500" required>
                </div>

                <div class="input-group">
                    <!--Campo Descrição-->
                    <input type="text" name="idEstoque" id="idEstoque" placeholder="Identificador do Produto no Estoque" minlength="1" required>
                </div>


                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeEditar()">Cancelar</a>
                    <button class="submit">Editar</button>
                </div>
                <!--Fim Formulário Modal Editar -->
            </form>
        </div>
        <!--Fim Corpo Modal Editar-->
    </div>
    <!--Fim Container Modal Editar-->

    <div class="modal-overlay modal-overlay-deletar">
        <!--Container do Modal Deletar-->
        <div class="modal">
            <!--Modal-->
            <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Deletar Produto</h2>
            <!--Titulo Modal-->
            <form method="POST" action="produtos/deleta_produto.php" id="form">
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="produto" id="produto" placeholder="Nome do Produto" required>
                </div>

                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeDeletar()">Cancelar</a>
                    <input type="submit" class="submit" value="Deletar">
                </div>
            </form>
            <!--Fim Formulário Modal Deletar-->
        </div>
        <!--Fim Corpo Modal-->
    </div>
    <!--Fim Container Modal Consultar-->

    <footer>
        <p>System Store ©</p>
    </footer>

    <script>
        Modal = {
            openAdicionar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay")
                    .classList.add('active')

            },
            closeAdicionar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay")
                    .classList.remove('active')
            },

            openConsultar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay-consultar")
                    .classList.add('active')

            },
            closeConsultar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay-consultar")
                    .classList.remove('active')
            },

            openEditar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay-editar")
                    .classList.add('active')

            },
            closeEditar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay-editar")
                    .classList.remove('active')
            },
            openDeletar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay-deletar")
                    .classList.add('active')

            },
            closeDeletar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay-deletar")
                    .classList.remove('active')
            },
        }
    </script>
</body>

</html>