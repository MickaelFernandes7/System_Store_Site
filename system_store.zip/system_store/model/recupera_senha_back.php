<?php
    //conectar ao banco
    include "../model/connect.php";

    //pesquisar usuario e senha do banco
    // receber os dados do formulario
    $email = isset($_POST['mail']) ? $_POST['mail'] : '';
    $senha = isset($_POST['senha']) ? $_POST['senha'] : '';
    $confirmSenha = isset($_POST['confirmSenha']) ? $_POST['confirmSenha'] : '';

    if($senha == $confirmSenha){
    $sql = "UPDATE usuario SET senha = '$confirmSenha' WHERE email = '$email'";

    $result = $conexao->query($sql);
    
    echo "<br>";

    // testar se o cadastro foi feito com sucesso
    if ($result) {
        echo "<script> alert('Senha alterada com Sucesso!');window.location='../index.php'</script>";
    } else {
        echo "<script> alert('Erro ao atualizar os dados do usuário, conferir se os dados foram digitados corretamente.')</script>" .$conexao->error;
        header('Location: recupera_senha.php');}
    }
    else{
        echo"<script> alert('Senha incorreta')</script>";
        header('Location: recupera_senha.php');
    }

    //encerrar conexão
    $conexao->close();
    
