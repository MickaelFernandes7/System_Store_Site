<?php
include "../config/config.php";

//flag para exibir mensagem para debug
$flag_exibir = true;

$conexao = new mysqli($hostname, $username, $password, $database);


if($conexao->connect_error){
    die("Erro de conexão: " . $conexao->connect_error);
}

?>