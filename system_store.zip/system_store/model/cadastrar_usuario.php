<?php
session_start();
//include de conexão ao banco de dados
include "connect.php";

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$tipo = $_POST['tipo'];


//Variável query com o comando MYSQL para inserir os dados com base nas variáveis
$sql = ("INSERT INTO usuario(nome, email, senha, tipo) 
VALUES ('$nome', '$email', '$senha', '$tipo')");

//realizar o insert de dados
$resultado = $conexao->query($sql);

//IF de confirmação no processo
if ($resultado) {
    $_SESSION['status'] = 'Usuário cadastrado com sucesso';
    header('Location: ../view/formulario_cadastro.php');
} else {
    echo "Erro no cadastro!";
}

$conexao->close();
