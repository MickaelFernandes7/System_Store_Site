<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inicial Administrador</title>
    <!--Link Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!-- Link css -->
    <link rel="stylesheet" href="css/main.css">
    <link rel="shortcut icon" type="imagex/png" href="assets/logo-cuted.jpeg">
</head>

<body>

    <?php
    session_start();
    ?>

    <?php
    //testar se o usuario está logado

    //verificar se existe uma sessão aberta no server
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    //proteger caso o usúario tente acessar a página do adm, e vice-versa
    if ($_SESSION['tipo'] != 1) {
        session_destroy();
        header("location:index.php");
    }

    // testar se o usuario está logado ou não
    if (isset($_SESSION['nome'])) {
    } else {
        // apagar a variavel de sessão
        unset($_SESSION['nome']);
        header("Location: index.php");
    }

    ?>

    <?php
    if (isset($_SESSION['status'])) {
    ?>
        <div class='alert alert-success alerta'><strong>Sucesso !</strong> Cadastro realizado com sucesso</div>;

    <?php
        unset($_SESSION['status']);
    }
    ?>

    <main>
        <header>
            <!--Início Header-->
            <nav class="nav">
                <p>
                    <!--Ícone de usuário-->
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="#fff" class="bi bi-person" viewBox="0 0 16 16">
                        <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                    </svg>
                    <?php //Início da Sessão
                    echo $_SESSION['nome']; //Nome do usuário
                    ?>
                </p>
            </nav>

            <div class="dropdown m-2">
                <!--Container Dropdown-->
                <button class="btn dropdown-toggle bg-light text-danger" type="button" id="dropdownMenu2" data-bs-toggle="dropdown" aria-expanded="false">
                    Menu
                </button>

                <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
                    <!--Lista de Botões do Dropdown-->
                    <a href="view/formulario_cadastro.php">
                        <li><button class="dropdown-item text-danger" type="button">Cadastrar Usuário</button></li>
                    </a>

                    <a href="model/backup.php">
                        <li><button class="dropdown-item text-danger" type="button">Fazer Backup do Banco de Dados da Loja</button></li>
                    </a>

                    <a href="model/frete.html">
                        <li><button class="dropdown-item text-danger" type="button">Calcular Frete</button></li>
                    </a>

                    <a href="view/logout.php">
                        <li><button class="dropdown-item text-danger" type="button">Sair</button></li>
                    </a>

                </ul>
                <!--Lista de Botões do Dropdown-->
            </div>
            <!--FIM Container Dropdown-->
        </header>
        <!--Fim Header-->

        <section class="mt-4">
            <a href="compras.php">
                <!--Início Link Compra-->
                <!--CARDS-->
                <div class="card m-2 border-0">
                    <!--Início do Card Compras-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130" fill="#fff" class="bi bi-bag-check-fill img" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M10.5 3.5a2.5 2.5 0 0 0-5 0V4h5v-.5zm1 0V4H15v10a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V4h3.5v-.5a3.5 3.5 0 1 1 7 0zm-.646 5.354a.5.5 0 0 0-.708-.708L7.5 10.793 6.354 9.646a.5.5 0 1 0-.708.708l1.5 1.5a.5.5 0 0 0 .708 0l3-3z" />
                        </svg>
                    </div>
                    <!--Fim do Div da Imagem-->

                    <div class="card-title-content">
                        <!--Div Título-->
                        <p class="card-title">Compras</p>
                    </div>
                    <!--Fim Título-->
                </div>
                <!--Fim do Card Compras-->
            </a>
            <!--Fim Link Compra-->

            <a href="estoque.php">
                <!--Inicio Link Estque-->
                <div class="card m-2 border-0">
                    <!--Início do Card Estoque-->
                    <div class="img-content">
                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130" fill="#fff" class="bi bi-shop img" viewBox="0 0 16 16">
                            <path d="M2.97 1.35A1 1 0 0 1 3.73 1h8.54a1 1 0 0 1 .76.35l2.609 3.044A1.5 1.5 0 0 1 16 5.37v.255a2.375 2.375 0 0 1-4.25 1.458A2.371 2.371 0 0 1 9.875 8 2.37 2.37 0 0 1 8 7.083 2.37 2.37 0 0 1 6.125 8a2.37 2.37 0 0 1-1.875-.917A2.375 2.375 0 0 1 0 5.625V5.37a1.5 1.5 0 0 1 .361-.976l2.61-3.045zm1.78 4.275a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 1 0 2.75 0V5.37a.5.5 0 0 0-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 0 0 1 5.37v.255a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0zM1.5 8.5A.5.5 0 0 1 2 9v6h1v-5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v5h6V9a.5.5 0 0 1 1 0v6h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V9a.5.5 0 0 1 .5-.5zM4 15h3v-5H4v5zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3zm3 0h-2v3h2v-3z" />
                        </svg>
                    </div>
                    <div class="card-title-content">
                        <!--Início do Título Estoque-->
                        <p class="card-title">Estoque</p>
                    </div>
                    <!--Fim do Título Estoque-->
                </div>
                <!--Fim do Card Estoque-->
            </a>
            <!--Fim Link Estoque-->

            <a href="produtos.php">
                <!--Inicio Link Produtos-->
                <div class="card m-2 border-0">
                    <!--Início do Card Produtos-->
                    <div class="img-content img">
                        <!--Div Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130" fill="currentColor" class="bi bi-box-seam" viewBox="0 0 16 16">
                            <path d="M8.186 1.113a.5.5 0 0 0-.372 0L1.846 3.5l2.404.961L10.404 2l-2.218-.887zm3.564 1.426L5.596 5 8 5.961 14.154 3.5l-2.404-.961zm3.25 1.7-6.5 2.6v7.922l6.5-2.6V4.24zM7.5 14.762V6.838L1 4.239v7.923l6.5 2.6zM7.443.184a1.5 1.5 0 0 1 1.114 0l7.129 2.852A.5.5 0 0 1 16 3.5v8.662a1 1 0 0 1-.629.928l-7.185 2.874a.5.5 0 0 1-.372 0L.63 13.09a1 1 0 0 1-.63-.928V3.5a.5.5 0 0 1 .314-.464L7.443.184z" />
                        </svg>
                    </div>
                    <!--Fim Div Imagem-->

                    <div class="card-title-content">
                        <!--Início do Título Produtos-->
                        <p class="card-title">Produtos</p>
                    </div>
                    <!--Fim do Título Produtos-->
                </div>
                <!--Fim do Card Produtos-->
            </a>
            <!--Fim Link Produtos-->

            <a href="vendas.php">
                <div class="card m-2 border-0">
                    <!--Início do Card Vendas-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130" fill="#fff" class="bi bi-currency-dollar img" viewBox="0 0 16 16">
                            <path d="M4 10.781c.148 1.667 1.513 2.85 3.591 3.003V15h1.043v-1.216c2.27-.179 3.678-1.438 3.678-3.3 0-1.59-.947-2.51-2.956-3.028l-.722-.187V3.467c1.122.11 1.879.714 2.07 1.616h1.47c-.166-1.6-1.54-2.748-3.54-2.875V1H7.591v1.233c-1.939.23-3.27 1.472-3.27 3.156 0 1.454.966 2.483 2.661 2.917l.61.162v4.031c-1.149-.17-1.94-.8-2.131-1.718H4zm3.391-3.836c-1.043-.263-1.6-.825-1.6-1.616 0-.944.704-1.641 1.8-1.828v3.495l-.2-.05zm1.591 1.872c1.287.323 1.852.859 1.852 1.769 0 1.097-.826 1.828-2.2 1.939V8.73l.348.086z" />
                        </svg>
                        <!--Fim Div da Imagem-->
                    </div>
                    <!--Início Link Vendas-->
                    <div class="card-title-content2">
                        <!--Div Título Vendas-->
                        <p class="card-title2">Controle de Vendas</p>
                    </div>
                    <!--Fim Div Título Vendas-->
                </div>
                <!--Fim do Card Vendas-->
            </a>
            <!--Fim Link Vendas-->

            <a href="vendas_produtos.php">
                <div class="card m-2 border-0">
                    <!--Início do Card Vendas-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="130" height="130" fill="#fff" class="bi bi-coin" viewBox="0 0 16 16">
                            <path d="M5.5 9.511c.076.954.83 1.697 2.182 1.785V12h.6v-.709c1.4-.098 2.218-.846 2.218-1.932 0-.987-.626-1.496-1.745-1.76l-.473-.112V5.57c.6.068.982.396 1.074.85h1.052c-.076-.919-.864-1.638-2.126-1.716V4h-.6v.719c-1.195.117-2.01.836-2.01 1.853 0 .9.606 1.472 1.613 1.707l.397.098v2.034c-.615-.093-1.022-.43-1.114-.9H5.5zm2.177-2.166c-.59-.137-.91-.416-.91-.836 0-.47.345-.822.915-.925v1.76h-.005zm.692 1.193c.717.166 1.048.435 1.048.91 0 .542-.412.914-1.135.982V8.518l.087.02z" />
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                            <path d="M8 13.5a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11zm0 .5A6 6 0 1 0 8 2a6 6 0 0 0 0 12z" />
                        </svg>
                        <!--Fim Div da Imagem-->
                    </div>
                    <!--Início Link Vendas-->
                    <div class="card-title-content2">
                        <!--Div Título Vendas-->
                        <p class="card-title2">Vendas dos Produtos</p>
                    </div>
                    <!--Fim Div Título Vendas-->
                </div>
                <!--Fim do Card Vendas-->
            </a>
            <!--Fim Link Vendas-->
        </section>

        <footer>
            <p>System Store ©</p>
        </footer>

    </main>
</body>

</html>