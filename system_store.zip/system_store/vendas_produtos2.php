<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendas Dos Produtos Funcionário</title>
    <link rel="stylesheet" href="css/modals.css">
    <link rel="shortcut icon" type="imagex/png" href="assets/logo-cuted.jpeg">
</head>

<body>

    <?php
    session_start();
    ?>

    <?php
    //testar se o usuario está logado

    //verificar se existe uma sessão aberta no server
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    //proteger caso o usúario tente acessar a página do adm, e vice-versa
    if ($_SESSION['tipo'] != 2) {
        session_destroy();
        header("location:index.php");
    }

    // testar se o usuario está logado ou não
    if (isset($_SESSION['nome'])) {
    } else {
        // apagar a variavel de sessão
        unset($_SESSION['nome']);
        header("Location: index.php");
    }

    ?>

    <main>
        <header>
            <div class="container">
                <!--Container Icone e Texto-->
                <div class="row">
                    <!--Linha da Div-->
                    <div class="col">
                        <!--Coluna da Div-->
                        <!--Icone-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" fill="#fff" class="bi bi-coin icon" viewBox="0 0 16 16">
                            <path d="M5.5 9.511c.076.954.83 1.697 2.182 1.785V12h.6v-.709c1.4-.098 2.218-.846 2.218-1.932 0-.987-.626-1.496-1.745-1.76l-.473-.112V5.57c.6.068.982.396 1.074.85h1.052c-.076-.919-.864-1.638-2.126-1.716V4h-.6v.719c-1.195.117-2.01.836-2.01 1.853 0 .9.606 1.472 1.613 1.707l.397.098v2.034c-.615-.093-1.022-.43-1.114-.9H5.5zm2.177-2.166c-.59-.137-.91-.416-.91-.836 0-.47.345-.822.915-.925v1.76h-.005zm.692 1.193c.717.166 1.048.435 1.048.91 0 .542-.412.914-1.135.982V8.518l.087.02z" />
                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                            <path d="M8 13.5a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11zm0 .5A6 6 0 1 0 8 2a6 6 0 0 0 0 12z" />
                        </svg>
                    </div>
                    <!--Fim Coluna da Div-->
                </div>
                <!--Fim Linha da Div-->

                <div class="row">
                    <!--Linha da Div-->
                    <div class="col">
                        <!--Coluna da Div-->

                        <h2 class="title">Vendas dos Produtos</h2>

                        <br>

                        <p class="text">Adicione e confira os ganhos recebidos pelas vendas dos produtos.</p>

                        <p class="text">Os ganhos podem ser adicionados e consultados pela quantidade da venda, e o valor do produto vendido.</p>

                        <p class="text">E automaticamente o calculo do ganho total por venda será realizado.</p>
                    </div>
                </div>
                <!--Fim Coluna da Div-->

                <div class="row">
                    <div class="col">
                        <a href="main2.php">
                            <svg style="margin-top: 25px; margin-right:10px;" xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="#fff" class="bi bi-x-lg" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M13.854 2.146a.5.5 0 0 1 0 .708l-11 11a.5.5 0 0 1-.708-.708l11-11a.5.5 0 0 1 .708 0Z" />
                                <path fill-rule="evenodd" d="M2.146 2.146a.5.5 0 0 0 0 .708l11 11a.5.5 0 0 0 .708-.708l-11-11a.5.5 0 0 0-.708 0Z" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <!--Fim Linha da Div-->
        </header>

        <section>
            <!--CARDS-->
            <a href="#" onclick="Modal.openAdicionar()">
                <!--Link Modal Adicionar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Adicionar-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-plus-circle-fill" viewBox="0 0 16 16">
                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z" />
                        </svg>
                    </div>
                    <!--Fim do Div da Imagem-->

                    <div class="card-title-content">
                        <!--Div Título-->
                        <p class="card-title">Adicionar</p>
                    </div>
                    <!--Fim Título-->
                </div>
                <!--Fim do Card Adicionar-->
            </a>
            <!--Fim Link Modal Adicionar-->

            <a href="#" onclick="Modal.openConsultar()">
                <!--Link Modal Consultar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Consultar-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-eye-fill" viewBox="0 0 16 16">
                            <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z" />
                            <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z" />
                        </svg>
                        <!--Fim Div da Imagem-->
                    </div>

                    <div class="card-title-content">
                        <!--Div Título Consultar-->
                        <p class="card-title">Consultar</p>
                    </div>
                    <!--Fim Div Título Consultar-->
                </div>
                <!--Fim do Card Consultar-->
            </a>
            <!--Fim Link Modal Consultar-->

            <a href="#" onclick="Modal.openEditar()">
                <!--Link Modal Editar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Editar-->
                    <div class="img-content">
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-pencil-square" viewBox="0 0 16 16">
                            <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                        </svg>
                    </div>
                    <div class="card-title-content">
                        <!--Início do Título Editar-->
                        <p class="card-title">Editar</p>
                    </div>
                    <!--Fim do Título Editar-->
                </div>
                <!--Fim do Card Editar-->
            </a>
            <!--Fim Link Modal Editar-->
            <!--CARDS-->
        </section>
    </main>

    <div class="modal-overlay">
        <!--Container do Modal Adicionar-->
        <div class="modal">
            <!--Modal-->
            <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Nova Venda</h2>
            <!--Titulo Modal-->
            <form method="POST" action="venda_produto/adicionar_venda_produto.php" id="form">
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="number" name="idVenda" placeholder="ID Venda" minlength="1" required>
                </div>

                <div class="input-group">
                    <!--Campo ID Produto-->
                    <input type="number" name="idProduto" id="idProduto" placeholder="ID do Produto" minlength="1" required>
                </div>

                <div class="input-group">
                    <!--Campo Preço-->
                    <input type="number" name="precoVendas" id="precoVendas" placeholder="Preço do Produto Vendido" required>
                </div>

                <div class="input-group">
                    <!--Campo Quantidade-->
                    <input type="number" name="quantidadeVendas" id="quantidadeVendas" placeholder="Quantidade do Produto Vendido" required>
                </div>

                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeAdicionar()">Cancelar</a>
                    <button type="submit" class="submit">Inserir</button>
                </div>
            </form>
            <!--Fim Formulário Modal-->
        </div>
        <!--Fim Corpo Modal-->
    </div>
    <!--Fim Container Modal Adicionar-->

    <div class="modal-overlay modal-overlay-consultar">
        <!--Container do Modal Consultar-->
        <div class="modal">
            <!--Modal-->
            <div class="modal-title">
                <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Consultar Venda do Produto</h2>
                <br>
                <a href="venda_produto/consultar_todas_vendas_produto2.php" style="color:#f55145; width:48%; font-size:14px; margin:5px 0 0 15px;">Consultar todas as Vendas</a>
            </div>
            <!--Titulo Modal-->
            <form method="POST" action="venda_produto/consultar_venda_produto2.php" id="form">
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="idVenda" id="idVenda" placeholder="ID da Venda do Produto" required>
                </div>

                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeConsultar()">Cancelar</a>
                    <button type="submit" class="submit">Consultar</button>
                </div>
            </form>
            <!--Fim Formulário Modal-->
        </div>
        <!--Fim Corpo Modal-->
    </div>
    <!--Fim Container Modal Consultar-->

    <div class="modal-overlay modal-overlay-editar">
        <!--Container do Modal Editar-->
        <div class="modal">
            <!--Modal-->
            <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Editar Venda do Produto</h2>
            <!--Titulo Modal-->
            <form method="POST" action="venda_produto/editar_venda_produto.php" id="form">

                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="number" name="idVenda" placeholder="Novo ID Venda" required>
                </div>

                <div class="input-group">
                    <!--Campo ID Produto-->
                    <input type="number" name="idProduto" id="idProduto" placeholder="Novo ID do Produto" minlength="1" required>
                </div>

                <div class="input-group">
                    <!--Campo Preço-->
                    <input type="number" name="precoVendas" id="precoVendas" placeholder="Novo Preço do Produto Vendido" required>
                </div>

                <div class="input-group">
                    <!--Campo Quantidade-->
                    <input type="number" name="quantidadeVendas" id="quantidadeVendas" placeholder="Nova Quantidade do Produto Vendido" required>
                </div>

                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeEditar()">Cancelar</a>
                    <button type="submit" class="submit">Editar</button>
                </div>
                <!--Fim Formulário Modal Editar -->
            </form>
        </div>
        <!--Fim Corpo Modal Editar-->
    </div>
    <!--Fim Container Modal Editar-->

    <footer>
        <p>System Store ©</p>
    </footer>

    <script>
        Modal = {
            openAdicionar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay")
                    .classList.add('active')

            },
            closeAdicionar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay")
                    .classList.remove('active')
            },

            openConsultar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay-consultar")
                    .classList.add('active')

            },
            closeConsultar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay-consultar")
                    .classList.remove('active')
            },

            openEditar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay-editar")
                    .classList.add('active')

            },
            closeEditar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay-editar")
                    .classList.remove('active')
            }
        }
    </script>
</body>

</html>