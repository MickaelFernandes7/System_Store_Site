    -- DB REFORM
    DROP DATABASE db_loja;
    CREATE DATABASE db_loja;
    USE db_loja;
    ALTER DATABASE db_loja CHARACTER SET utf8 COLLATE utf8_unicode_ci;

    create table usuario(
    id int primary key auto_increment not null,
    nome varchar(255) default null,
    email varchar(255) unique default null,
    senha  varchar(20) not null,
    tipo int(1) not null,
    data timestamp default current_timestamp) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    create table tbl_compras(
    id_compras int AUTO_INCREMENT not null,
    nome_produto_compra varchar(100) not null,
    quantidade_produto_compra bigint not null,
    preco_produto_compra decimal(10,2) not null,
    data_compra date not null,
    valor_gasto_compra decimal(10,2) default 0 not null,
    primary key(id_compras), 
    data timestamp NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    create table tbl_estoque(
    id_estoque int AUTO_INCREMENT not null,
    nome_produto_estoque varchar(100) not null,
    quantidade_produto_estoque bigint unsigned not null,
    id_compras int not null,
    primary key(id_estoque),
    foreign key(id_compras) references tbl_compras(id_compras)) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    create table tbl_produto(
    id_produto int AUTO_INCREMENT not null,
    nome_produto VARCHAR(100) not null,
    preco_produto decimal(10,2) not null,
    descricao_produto VARCHAR(500) not null,
    id_estoque int not null,
    primary key(id_produto),
    foreign key(id_estoque) REFERENCES tbl_estoque(id_estoque)) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    create table tbl_vendas(
    id_vendas int AUTO_INCREMENT not null,
    nome_produto_vendas varchar(100) not null,
    quantidade_produto_vendas bigint not null,
    data_venda date not null,
    id_estoque int not null,
    primary key(id_vendas),
    foreign key(id_estoque) references tbl_estoque(id_estoque),
    data timestamp NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    create table tbl_venda_produto(
    id_vendas int not null,
    id_produto int not null,
    quantidade_vendas_produto bigint not null,
    preco_vendas_produto decimal(10,2) not null,
    valor_ganho_venda decimal(10,2) default 0 not null,
    foreign key(id_vendas) references tbl_vendas(id_vendas),
    foreign key(id_produto) references tbl_produto(id_produto),
    data timestamp NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    -- Triggers
    -- Triggers Compra
    create trigger tr_insert_valor_gasto before insert on tbl_compras for each row set new.valor_gasto_compra = (new.preco_produto_compra * new.quantidade_produto_compra);

    create trigger tr_update_valor_gasto before update on tbl_compras for each row set new.valor_gasto_compra = (new.preco_produto_compra * new.quantidade_produto_compra);

    -- Triggers Vendas
    -- alterar o trigger para a nova tabela associativa Venda_Produtos, o valor da venda vai estar contido nela.
     create trigger tr_insert_valor_ganho before insert on tbl_venda_produto for each row set new.valor_ganho_venda = (new.preco_vendas_produto * new.quantidade_vendas_produto);

    -- alterar o trigger para a nova tabela associativa Venda_Produtos, o valor da venda vai estar contido nela.
     create trigger tr_update_valor_ganho before update on tbl_venda_produto for each row set new.valor_ganho_venda = (new.preco_vendas_produto * new.quantidade_vendas_produto);

    -- Triggers Estoque
    -- Venda atualiza quantidade no estoque
    CREATE TRIGGER atualizar_estoque_venda after insert on tbl_vendas
    for each row 
    UPDATE tbl_estoque 
    INNER JOIN tbl_vendas ON tbl_estoque.id_estoque = tbl_vendas.id_estoque
    SET tbl_estoque.quantidade_produto_estoque = tbl_estoque.quantidade_produto_estoque- tbl_vendas.quantidade_produto_vendas
    WHERE tbl_estoque.id_estoque = NEW.id_estoque;

    -- INSERT Usuarios

    INSERT INTO usuario (nome, email, senha, tipo) VALUES('admin', 'admin@gmail.com', '1234', 1);
    INSERT INTO usuario (nome, email, senha, tipo) VALUES('Mickael', 'mickaelbpsouza@gmail.com', '1234', 2);
    INSERT INTO usuario (nome, email, senha, tipo) VALUES('Guilherme', 'guilhermexavier@gmail.com', '1234', 3);