    -- DB REFORM
    drop database db_loja;
    CREATE DATABASE db_loja;
    USE db_loja;
    ALTER DATABASE db_loja CHARACTER SET utf8 COLLATE utf8_unicode_ci;

    create table usuario(
    id int primary key auto_increment not null,
    nome varchar(255) default null,
    email varchar(255) unique default null,
    senha  varchar(20) not null,
    tipo int(1) not null,
    data timestamp default current_timestamp) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    create table tbl_compras(
    id_compras int AUTO_INCREMENT not null,
    nome_produto_compra varchar(100) not null,
    quantidade_produto_compra bigint not null,
    preco_produto_compra decimal(10,2) not null,
    data_compra date not null,
    valor_gasto_compra decimal(10,2) default 0 not null,
    primary key(id_compras), 
    data timestamp NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    create table tbl_estoque(
    id_estoque int AUTO_INCREMENT not null,
    nome_produto_estoque varchar(100) not null,
    quantidade_produto_estoque bigint unsigned not null,
    id_compras int not null,
    primary key(id_estoque),
    foreign key(id_compras) references tbl_compras(id_compras)) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    create table tbl_produto(
    id_produto int AUTO_INCREMENT not null,
    nome_produto VARCHAR(100) not null,
    preco_produto decimal(10,2) not null,
    descricao_produto VARCHAR(500) not null,
    id_estoque int not null,
    primary key(id_produto),
    foreign key(id_estoque) REFERENCES tbl_estoque(id_estoque)) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    create table tbl_vendas(
    id_vendas int AUTO_INCREMENT not null,
    nome_produto_vendas varchar(100) not null,
    quantidade_produto_vendas bigint not null,
    data_venda date not null,
    id_estoque int not null,
    primary key(id_vendas),
    foreign key(id_estoque) references tbl_estoque(id_estoque),
    data timestamp NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    create table tbl_venda_produto(
    id_vendas int not null,
    id_produto int not null,
    quantidade_vendas_produto bigint not null,
    preco_vendas_produto decimal(10,2) not null,
    valor_ganho_venda decimal(10,2) default 0 not null,
    foreign key(id_vendas) references tbl_vendas(id_vendas),
    foreign key(id_produto) references tbl_produto(id_produto),
    data timestamp NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    -- Triggers
    -- Triggers Compra
    create trigger tr_insert_valor_gasto before insert on tbl_compras for each row set new.valor_gasto_compra = (new.preco_produto_compra * new.quantidade_produto_compra);

    create trigger tr_update_valor_gasto before update on tbl_compras for each row set new.valor_gasto_compra = (new.preco_produto_compra * new.quantidade_produto_compra);

    -- Triggers Vendas
    -- alterar o trigger para a nova tabela associativa Venda_Produtos, o valor da venda vai estar contido nela.
     create trigger tr_insert_valor_ganho before insert on tbl_venda_produto for each row set new.valor_ganho_venda = (new.preco_vendas_produto * new.quantidade_vendas_produto);

    -- alterar o trigger para a nova tabela associativa Venda_Produtos, o valor da venda vai estar contido nela.
     create trigger tr_update_valor_ganho before update on tbl_venda_produto for each row set new.valor_ganho_venda = (new.preco_vendas_produto * new.quantidade_vendas_produto);

    -- Triggers Estoque
    -- Venda atualiza quantidade no estoque
    CREATE TRIGGER atualizar_estoque_venda after insert on tbl_vendas
    for each row 
    UPDATE tbl_estoque 
    INNER JOIN tbl_vendas ON tbl_estoque.id_estoque = tbl_vendas.id_estoque
    SET tbl_estoque.quantidade_produto_estoque = tbl_estoque.quantidade_produto_estoque- tbl_vendas.quantidade_produto_vendas
    WHERE tbl_estoque.id_estoque = NEW.id_estoque;

    -- INSERT Usuarios
    INSERT INTO usuario (nome, email, senha, tipo) VALUES('Mickael', 'mickaelbpsouza@gmail.com', '1234', 1);
    INSERT INTO usuario (nome, email, senha, tipo) VALUES('Guilherme', 'guilhermexavier@gmail.com', '1234', 2);

    -- INSERT Compras
    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(1, 'Camisa', 10, 50.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(2, 'Caderno', 15, 14.75, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(3, 'Vassoura', 10, 4.90, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(4, 'Estojo', 10, 8.50, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(5, 'Carregador de Celular', 20, 10.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(6, 'Garrafa de Agua', 30, 3.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(7, 'Garrafa de Refrigerante Fanta', 20, 6.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(8, 'Garrafa de Refrigerante Coca-Cola', 25, 9.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(9, 'Cartela de Cigarro', 20, 6.50, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(10, 'Salgadinho', 30, 5.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(11, 'Barra de Chocolate', 15, 6.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(12, 'Barra de Chocolate Branco', 15, 6.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(13, 'Carvao', 15, 13.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(14, 'Gelo', 15, 8.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(15, 'Vodka', 10, 50.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(16, 'Suco de Garrafa', 15, 7.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(17, 'Suco de Caixa', 10, 10.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(18, 'Pipoca Doce', 10, 2.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(19, 'Caixa de Doce de Leite', 10, 5.00, '2022/05/13');

    insert into tbl_compras(id_compras, nome_produto_compra, quantidade_produto_compra, preco_produto_compra, data_compra) VALUES(20, 'Cabo USB', 10, 5.00, '2022/05/13');

    -- INSERT Estoque
    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(1, 'Camisa', 10, 1);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(2, 'Caderno', 15, 2);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(3, 'Vassoura', 10, 3);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(4, 'Estojo', 10, 4);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(5, 'Carregador de Celular', 20, 5);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(6, 'Garrafa de Agua', 30, 6);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(7, 'Garrafa de Refrigerante Fanta', 30, 7);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(8, 'Garrafa de Refrigerante Coca-Cola', 30, 8);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(9, 'Cartela de Cigarro', 20, 9);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(10, 'Salgadinho', 30, 10);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(11, 'Barra de Chocolate', 15, 11);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(12, 'Barra de Chocolate Branco', 15, 12);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(13, 'Carvao', 15, 13);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(14, 'Gelo', 15, 14);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(15, 'Vodka', 10, 15);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(16, 'Suco de Garrafa', 15, 16);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(17, 'Suco de Caixa', 10, 17);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(18, 'Pipoca Doce', 10, 18);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(19, 'Caixa de Doce de Leite', 10, 19);

    insert into tbl_estoque(id_estoque, nome_produto_estoque, quantidade_produto_estoque, id_compras) VALUES(20, 'Cabo USB', 10, 20);

    -- INSERT Produtos
    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(1, 'Camisa', 14, 'Texto Comum', 1);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(2, 'Caderno', 20, 'Texto Comum', 2);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(3, 'Vassoura', 8, 'Texto Comum', 3);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(4, 'Estojo', 7, 'Texto Comum', 4);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(5, 'Carregador de Celular', 10, 'Texto Comum', 5);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(6, 'Garrafa de Agua', 6, 'Texto Comum', 6);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(7, 'Garrafa de Refrigerante Fanta', 10, 'Texto Comum', 7);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(8, 'Garrafa de Refrigerante Coca-Cola', 14, 'Texto Comum', 8);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(9, 'Cartela de Cigarro', 8, 'Texto Comum', 9);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(10, 'Salgadinho', 6.50, 'Texto Comum', 10);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(11, 'Barra de Chocolate', 8, 'Texto Comum', 11);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(12, 'Barra de Chocolate Branco', 8, 'Texto Comum', 12);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(13, 'Carvao', 12, 'Texto Comum', 13);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(14, 'Gelo', 10, 'Texto Comum', 14);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(15, 'Vodka', 65, 'Texto Comum', 15);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(16, 'Suco de Garrafa', 8, 'Texto Comum', 16);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(17, 'Suco de Caixa', 10, 'Texto Comum', 17);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(18, 'Pipoca Doce', 4, 'Texto Comum', 18);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(19, 'Caixa de Doce de Leite', 12, 'Texto Comum', 19);

    insert into tbl_produto(id_produto, nome_produto, preco_produto, descricao_produto, id_estoque)VALUES(20, 'Cabo USB', 9, 'Texto Comum', 20);

    
    -- INSERT Vendas
    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(1, 'Camisa', 5, 1, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(2, 'Caderno', 5, 2, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(3, 'Vassoura', 5, 3, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(4, 'Estojo', 5, 4, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(5, 'Carregador de Celular', 5, 5, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(6, 'Garrafa de Agua', 5, 6, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(7, 'Garrafa de Refrigerante Fanta', 5, 7, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque,  data_venda) VALUES(8, 'Garrafa de Refrigerante Coca-Cola', 5,  8, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque,  data_venda) VALUES(9, 'Cartela de Cigarro',  5, 9, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque,  data_venda) VALUES(10, 'Salgadinho', 5, 10, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(11, 'Barra de Chocolate', 5, 11, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(12, 'Barra de Chocolate Branco', 5, 12, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(13, 'Carvao', 5, 13, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(14, 'Gelo', 5, 14, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(15, 'Vodka', 5, 15, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(16, 'Suco de Garrafa', 5, 16, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(17, 'Suco de Caixa', 5, 17, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(18, 'Pipoca Doce', 5, 18, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(19, 'Caixa de Doce de Leite', 5, 19, '2022-05-17');

    insert into tbl_vendas(id_vendas, nome_produto_vendas, quantidade_produto_vendas, id_estoque, data_venda) VALUES(20, 'Cabo USB', 5, 20, '2022-05-17');


    -- INSERT VENDA PRODUTO
    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(1, 1, 10, 50);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(2, 2, 10, 14.75);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(3, 3, 10, 4.90);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(4, 4, 10, 8.50);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(5, 5, 10, 10.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(6, 6, 10, 3.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(7, 7, 10, 6.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(8, 8, 10, 9.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(9, 9, 10, 5.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(10, 10, 10, 6.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(11, 11, 10, 6.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(12, 12, 10, 6.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(13, 13, 10, 13.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto)VALUES(14, 14, 10, 8.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(15, 15, 10, 50.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(16, 16, 10, 7.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(17, 17, 10, 10.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(18, 18, 10, 2.00);

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(19, 19, 10, 5.00);;

    insert into tbl_venda_produto(id_vendas, id_produto, quantidade_vendas_produto, preco_vendas_produto) VALUES(20, 20, 10, 5.00);