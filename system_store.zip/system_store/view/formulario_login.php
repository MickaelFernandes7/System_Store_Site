<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/login.css">
    <link rel="shortcut icon" type="imagex/png" href="../assets/logo-cuted.jpeg">
</head>

<body>
    <div class="container">
        <!--Inicio do container -->
        <div>
            <div class="card">
                <!--Alterar a cor do bakcground do form-->
                <div class=" text-white" style="background-color: #f55145; outline:none; text-align:center;">
                    <!--Cabeçalho do FORM-->
                    <svg xmlns="http://www.w3.org/2000/svg" width="110" height="110" fill="#fff" class="bi bi-person img" viewBox="0 0 16 16">
                        <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                    </svg>
                </div><!-- FIM do Cabeçalho do FORM-->

                <div class="card-body">
                    <!-- Inicio do Body do FORM-->
                    <form method="POST" action="#">
                        <!-- Início do FORM-->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- INICIO Container field Nome-->
                                <label for="inputNome" class="form-label" id="labelUser">Usuário</label>
                                <input type="text" name="nome" id="inputNome" class="form-control" placeholder="Nome de Usuário" required>
                            </div>
                            <!--FIM Container field Nome-->
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <!-- INICIO Container field Senha-->
                                <label for="inputSenha" class="form-label" id="labelSenha">Senha</label>
                                <input type="password" name="senha" id="inputSenha" class="form-control" placeholder="Senha" minlength="4" maxlength="20" required>
                            </div>
                            <!--FIM Container field Senha-->
                        </div>

                        <div class="pt-3">
                        <label for="inputNome" class="form-label" id="labelTipo">Tipo</label>
                            <select name="tipo" id="cDocente" class="form-control" required>
                                <option value="1">Administrador</option>
                                <option value="2">Funcionário</option>
                            </select>
                        </div>

                        <br>

                        <input type="submit" value="Entrar" class="btn" style="background-color: #fff; color:#f55145; width:100%">
                    </form>
                    <br>
                    <!-- Esqueceu sua senha -->

                    <a href="../model/recupera_senha.php" class="text-light fs-6 esqueceu">Esqueceu Sua Senha?</a>

                </div><!-- FIM do FORM-->
            </div><!-- FIM do Body do FORM-->
        </div>
    </div>
    <!--Fim Container-->

<?php

//conectar ao banco
include "../model/connect.php";

//pesquisar usuario e senha do banco
// receber os dados do formulario
$nome = isset($_POST['nome']) ? $_POST['nome'] : '';
$senha = isset($_POST['senha']) ? $_POST['senha'] : '';
$tipo = isset($_POST['tipo']) ? $_POST['tipo'] : '';


// query de busca do banco
if (isset($_POST['nome']) && isset($_POST['senha'])) {
    $sql = "SELECT nome, senha, tipo from usuario where nome='$nome' AND senha ='$senha' AND tipo = '$tipo'";

    // recebe a quantidade de registro(0 = login errado & 1 = login certo)
    $result = $conexao->query($sql);

    //testar se tem registro && se o solicitante é ADM ou usúario 
    if ($result->num_rows === 1 && $tipo === '1') {

        //iniciar uma sessão do servidor
        session_start();
        // criar uma variável de sessão no server
        $_SESSION['nome'] = $nome;
        $_SESSION['tipo'] = $tipo;
        header("Location: ../main.php");
    }
    //testar se tem registro && se o solicitante é ADM ou usúario 
    elseif ($result->num_rows === 1 && $tipo === '2') {

        //iniciar uma sessão do servidor
        session_start();
        // criar uma variável de sessão no server
        $_SESSION['nome'] = $nome;
        $_SESSION['tipo'] = $tipo;
        header("Location: ../main2.php");

    } else {
        echo "<div class='alert alert-danger alerta'><strong>Erro!</strong> Email/Senha ou Tipo Inválidos </div>";
    }
}
?>

</body>

</html>