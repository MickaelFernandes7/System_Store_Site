<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Usuário</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/cadastro_login.css">
    <link rel="shortcut icon" type="imagex/png" href="../assets/logo-cuted.jpeg">
</head>

<body style="background-image:url('../assets/background.jpeg'); height: 300px;">

    <?php
    session_start();
    ?>

    <?php
    //testar se o usuario está logado
    //verificar se existe uma sessão aberta no server
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    //proteger caso o usúario tente acessar a página do adm, e vice-versa
    if ($_SESSION['tipo'] != 1) {
        session_destroy();
        header("location:../index.php");
    }

    // testar se o usuario está logado ou não
    if (isset($_SESSION['nome'])) {
    } else {
        // apagar a variavel de sessão
        unset($_SESSION['nome']);
        header("Location: ../index.php");
    }
    ?>

    <?php
    if (isset($_SESSION['status'])) {

    ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Usuário cadastrado com sucesso !</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
        </div>

    <?php

        unset($_SESSION['status']);
    }
    ?>

    <div class="container">
        <!--Inicio do container -->
        <div>
            <div class="card" style="background-color:#f55145; color:#fff; font-size:20px;margin-top:-75px; margin-bottom:12px">
                <!--Alterar a cor do bakcground do form-->
                <div class=" text-white" style="background-color: #f55145; outline:none; text-align:center;">
                    <!--Cabeçalho do FORM-->
                    <svg xmlns="http://www.w3.org/2000/svg" width="110" height="110" fill="#fff" class="bi bi-person img" viewBox="0 0 16 16">
                        <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                    </svg>
                </div><!-- FIM do Cabeçalho do FORM-->

                <div class="card-body">
                    <!-- Inicio do Body do FORM-->
                    <form method="POST" action="../model/cadastrar_usuario.php" enctype="multipart/form-data">
                        <!-- Início do FORM-->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- INICIO Container field Nome-->
                                <label for="inputNome" class="form-label" id="labelUser">Usuário</label>
                                <input type="text" name="nome" id="inputNome" class="form-control inputs" placeholder="Nome de Usuário" minlength="3" maxlength="255" required>
                            </div>
                            <!--FIM Container field Nome-->
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <!-- INICIO Container field E-mail-->
                                <label for="inputEmail" class="form-label" id="labelEmail">E-mail</label>
                                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="E-mail" minlength="10" maxlength="255" required>
                            </div>
                            <!--FIM Container field E-mail-->
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <!-- INICIO Container field Senha-->
                                <label for="inputSenha" class="form-label" id="labelSenha">Senha</label>
                                <input type="password" name="senha" id="inputSenha" class="form-control" placeholder="Senha" minlength="4" maxlength="20" required>
                            </div>
                            <!--FIM Container field Senha-->
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <!-- INICIO Container field Senha-->
                                <label for="inputTipo" class="form-label" id="labelTipo">Tipo</label>
                                <input type="number" name="tipo" id="inputTipo" class="form-control" placeholder="(1) Administrador | (2) Funcionário" style="font-size:15px;" min="1" max="2" maxlength="1" required>
                            </div>
                            <!--FIM Container field Senha-->
                        </div>

                        <br>

                        <input type="submit" value="Cadastrar" class="btn" style="background-color: #fff; color:#f55145; width:100%">

                        <a href="../main.php" style="text-decoration: none;" class="text-white btn btn-dark form-control mt-3">Voltar</a>


                </div><!-- FIM do FORM-->
                </form>
            </div><!-- FIM do Body do FORM-->

        </div>
    </div>
    <!--Fim Container-->

</body>

</html>