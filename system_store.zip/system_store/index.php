<?php
header('Location: view/formulario_login.php'); 
?>