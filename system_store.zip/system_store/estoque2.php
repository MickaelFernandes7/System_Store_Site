<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estoque Funcionários</title>
    <link rel="stylesheet" href="css/modals.css">
    <link rel="shortcut icon" type="imagex/png" href="assets/logo-cuted.jpeg">
</head>

<body>

    <?php
    session_start();
    ?>

    <?php
    //testar se o usuario está logado

    //verificar se existe uma sessão aberta no server
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    //proteger caso o usúario tente acessar a página do adm, e vice-versa
    if($_SESSION['tipo'] != 2){
        session_destroy();
        header("location:index.php");
    }

    // testar se o usuario está logado ou não
    if (isset($_SESSION['nome'])) {
    } else {
        // apagar a variavel de sessão
        unset($_SESSION['nome']);
        header("Location: index.php");
    }

    ?>

    <main>
        <header>
            <div class="container">
                <!--Container Icone e Texto-->
                <div class="row">
                    <!--Linha da Div-->
                    <div class="col">
                        <!--Coluna da Div-->
                        <!--Icone-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-shop img icon" viewBox="0 0 16 16">
                            <path d="M2.97 1.35A1 1 0 0 1 3.73 1h8.54a1 1 0 0 1 .76.35l2.609 3.044A1.5 1.5 0 0 1 16 5.37v.255a2.375 2.375 0 0 1-4.25 1.458A2.371 2.371 0 0 1 9.875 8 2.37 2.37 0 0 1 8 7.083 2.37 2.37 0 0 1 6.125 8a2.37 2.37 0 0 1-1.875-.917A2.375 2.375 0 0 1 0 5.625V5.37a1.5 1.5 0 0 1 .361-.976l2.61-3.045zm1.78 4.275a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 1 0 2.75 0V5.37a.5.5 0 0 0-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 0 0 1 5.37v.255a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0zM1.5 8.5A.5.5 0 0 1 2 9v6h1v-5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v5h6V9a.5.5 0 0 1 1 0v6h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V9a.5.5 0 0 1 .5-.5zM4 15h3v-5H4v5zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3zm3 0h-2v3h2v-3z" />
                        </svg>
                    </div>
                    <!--Fim Coluna da Div-->
                </div>
                <!--Fim Linha da Div-->

                <div class="row">
                    <!--Linha da Div-->
                    <div class="col">
                        <!--Coluna da Div-->

                        <h2 class="title">Estoque</h2>

                        <br>

                        <p class="text">Adicione os produtos Comprados no seu estoque digital.</p>

                        <p class="text">Os produtos são adicionados no estoque, pelo
                            nome, seu valor, sua quantidade, sua descrição, e a data na qual o produto foi adicionado.</p>

                        <p class="text">Os produtos do estoque podem ser, adicionados, consultados, modificados, e deletados de
                            acordo
                            com
                            a necessidade.</p>
                    </div>
                </div>
                <!--Fim Coluna da Div-->

                <div class="row">
                    <div class="col">
                        <a href="main2.php">
                            <svg style="margin-top: 25px; margin-right:10px;" xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="#fff" class="bi bi-x-lg" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M13.854 2.146a.5.5 0 0 1 0 .708l-11 11a.5.5 0 0 1-.708-.708l11-11a.5.5 0 0 1 .708 0Z" />
                                <path fill-rule="evenodd" d="M2.146 2.146a.5.5 0 0 0 0 .708l11 11a.5.5 0 0 0 .708-.708l-11-11a.5.5 0 0 0-.708 0Z" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <!--Fim Linha da Div-->
        </header>

        <section>
            <!--CARDS-->
            <a href="#" onclick="Modal.openAdicionar()">
                <!--Link Modal Adicionar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Adicionar-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-plus-circle-fill" viewBox="0 0 16 16">
                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z" />
                        </svg>
                    </div>
                    <!--Fim do Div da Imagem-->

                    <div class="card-title-content">
                        <!--Div Título-->
                        <p class="card-title">Adicionar</p>
                    </div>
                    <!--Fim Título-->
                </div>
                <!--Fim do Card Adicionar-->
            </a>
            <!--Fim Link Modal Adicionar-->

            <a href="#" onclick="Modal.openConsultar()">
                <!--Link Modal Consultar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Consultar-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-eye-fill" viewBox="0 0 16 16">
                            <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z" />
                            <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z" />
                        </svg>
                        <!--Fim Div da Imagem-->
                    </div>

                    <div class="card-title-content">
                        <!--Div Título Consultar-->
                        <p class="card-title">Consultar</p>
                    </div>
                    <!--Fim Div Título Consultar-->
                </div>
                <!--Fim do Card Consultar-->
            </a>
            <!--Fim Link Modal Consultar-->

            <a href="#" onclick="Modal.openEditar()">
                <!--Link Modal Editar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Editar-->
                    <div class="img-content">
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-pencil-square" viewBox="0 0 16 16">
                            <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                        </svg>
                    </div>
                    <div class="card-title-content">
                        <!--Início do Título Editar-->
                        <p class="card-title">Editar</p>
                    </div>
                    <!--Fim do Título Editar-->
                </div>
                <!--Fim do Card Editar-->
            </a>
            <!--Fim Link Modal Editar-->
        </section>
    </main>

    <footer>
        <p>System Store ©</p>
    </footer>

    <div class="modal-overlay">
        <!--Container do Modal Adicionar-->
        <div class="modal">
            <!--Modal-->
            <h2 style="color:#f55145; font-family: fantasy, sans-serif; font-size:22px;">Adicionar Produto no Estoque</h2>
            <!--Titulo Modal-->
            <form method="POST" action="estoque/adicionar_estoque.php" id="form">
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="nomeProdutoEstoque" id="nomeProdutoEstoque" placeholder="Nome do Produto Para o Estoque" required>
                </div>

                <div class="input-group">
                    <!--Campo Quantidade-->
                    <input type="number" name="quantidadeEstoque" id="quantidadeEstoque" placeholder="Quantidade do Produto" required>
                </div>
    
                <div class="input-group">
                    <!--Campo ID da Compra-->
                    <input type="text" name="id_compra" id="descricao" placeholder="ID da Compra do Produto" required>
                </div>

                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeAdicionar()">Cancelar</a>
                    <button type="submit" class="submit">Inserir</button>
                </div>
            </form>
            <!--Fim Formulário Modal-->
        </div>
        <!--Fim Corpo Modal-->
    </div>
    <!--Fim Container Modal Adicionar-->

    <div class="modal-overlay modal-overlay-consultar">
        <!--Container do Modal Consultar-->
        <div class="modal">
            <!--Modal-->
            <div class="modal-title">
                <h2 style="color:#f55145; font-family: fantasy, sans-serif; font-size:22px; ">Consultar Produtos no Estoque</h2>
                <a href="estoque/consultaTodo_estoque2.php" style="color:#f55145; width:48%; font-size:14px; margin:5px 0 0 15px;">Consultar todos os Produtos</a>
            </div>
            <!--Titulo Modal-->
            <form method="POST" action="estoque/consultar_estoque2.php" id="form">
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="nomeProduto" id="nomeProduto" placeholder="Produto" required>
                </div>

                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeConsultar()">Cancelar</a>
                    <button type="submit" class="submit">Consultar</button>
                </div>
            </form>
            <!--Fim Formulário Modal-->
        </div>
        <!--Fim Corpo Modal-->
    </div>
    <!--Fim Container Modal Consultar-->

    <div class="modal-overlay modal-overlay-editar">
        <!--Container do Modal Editar-->
        <div class="modal">
            <!--Modal-->
            <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Editar Produto do Estoque</h2>
            <!--Titulo Modal-->
            <form method="POST" action="estoque/editar_estoque.php" id="form">
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="idEstoque" id="idEstoque" placeholder="ID Estoque" required>
                </div>
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="nomeProduto" id="nomeProduto" placeholder="Novo Nome do Produto" required>
                </div>

            
                <div class="input-group">
                    <!--Campo Quantidade-->
                    <input type="number" name="quantidade" id="quantidade" placeholder="Nova Quantidade do Produto" required>
                </div>

                <div class="input-group">
                    <!--Campo ID Compra-->
                    <input type="number" name="idCompra" id="idCompra" placeholder="Novo ID da Compra do Produto" required>
                </div>
                
                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeEditar()">Cancelar</a>
                    <button type="submit" class="submit">Editar</button>
                </div>
                <!--Fim Formulário Modal Editar -->
            </form>
        </div>
        <!--Fim Corpo Modal Editar-->
    </div>
    <!--Fim Container Modal Editar-->
    
    <script>
        Modal = {
            openAdicionar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay")
                    .classList.add('active')

            },
            closeAdicionar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay")
                    .classList.remove('active')
            },

            openConsultar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay-consultar")
                    .classList.add('active')

            },
            closeConsultar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay-consultar")
                    .classList.remove('active')
            },

            openEditar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay-editar")
                    .classList.add('active')

            },
            closeEditar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay-editar")
                    .classList.remove('active')
            }
        }
    </script>
</body>

</html>