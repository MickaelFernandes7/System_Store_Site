<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Estoque</title>
</head>

<body style="background-image:url('../assets/background.jpeg'); height: 300px;">

    <?php
    //include do script de conexao do banco de dados
    include "../model/connect.php";

// Tabela - tbl_esoque
/*
+----------------------------+---------------+------+-----+---------+----------------+
| Field                      | Type          | Null | Key | Default | Extra          |
+----------------------------+---------------+------+-----+---------+----------------+
| id_estoque                 | int           | NO   | PRI | NULL    | auto_increment |
| nome_produto_estoque       | varchar(100)  | NO   |     | NULL    |                |
| quantidade_produto_estoque | bigint        | NO   |     | NULL    |                |
| preco_produto_estoque      | decimal(10,2) | NO   |     | NULL    |                |
| id_compras                 | int           | NO   | MUL | NULL    |                |
| descrição_produto          | varchar(1000) | YES  |     | NULL    |                |
+----------------------------+---------------+------+-----+---------+----------------+
*/

    // resgatar as informacoes atraves do metodo Post, e salvar em variaveis
    $nomeProdEstoque = $_POST['nomeProdutoEstoque'];
    $qtdeProdEstoque = $_POST['quantidadeEstoque'];
    $idCompra = $_POST['id_compra'];

    session_start();

    $tipo = $_SESSION['tipo'];

 
    //query sql - insert
    $sql = "INSERT INTO tbl_estoque(
    nome_produto_estoque, 
    quantidade_produto_estoque, 
    id_compras
    ) VALUES(
        '$nomeProdEstoque',
        '$qtdeProdEstoque',
        '$idCompra'
    )";


    //insert no banco de dados
    $result = $conexao->query($sql);

    echo "<br>";

    // testar se o cadastro foi feito com sucesso
    if ($result && $tipo === '1') {
        echo "<script> alert('Produto Cadastrado com sucesso!');window.location='../estoque.php'</script>";;
        
    } elseif($result && $tipo === '2') {
        echo "<script> alert('Produto Cadastrado com sucesso!');window.location='../estoque2.php'</script>";;
    } else {
        echo "<div style='text-align:center'><h2>Erro ao inserir os dados</h2></div>". $conexao->error;
    }

    //encerrar conexão
    $conexao->close();
    ?>
</body>

</html>