<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
</head>

<body style="background-image:url('../assets/background.jpeg'); height:100%;">

    <?php
    //include do script de conexao do banco de dados
    include "../model/connect.php";

    // Tabela - tbl_compras

    // resgatar as informacoes atraves do metodo Post, e salvar em variaveis
    $nomeProdEstoque = $_POST['nomeProduto'];
    $qtdeProdEstoque = $_POST['quantidade'];
    $idEstoque = $_POST['idEstoque'];
    $id_compra = $_POST['idCompra'];

    session_start();

    $tipo = $_SESSION['tipo'];

    //query sql - update
    $sql = "UPDATE tbl_estoque
    SET nome_produto_estoque = '$nomeProdEstoque',
    quantidade_produto_estoque = '$qtdeProdEstoque',
    id_compras = '$id_compra'
    WHERE id_estoque = '$idEstoque'";


    $result = $conexao->query($sql);

    echo "<br>";

    // testar se o cadastro foi feito com sucesso
    if ($result && $tipo === '1') {
        echo "<script> alert('Dados atualizados com sucesso!');window.location='../estoque.php'</script>";
    } elseif($result && $tipo === '2') {
        echo "<script> alert('Dados atualizados com sucesso!');window.location='../estoque2.php'</script>";
    } else {
        echo "<script> alert('Erro ao atualizar os dados do produto, conferir se o identificador do produto está correto.'); window.location='../estoque.php'</script>" .$conexao->error;
    }

    //encerrar conexão
    $conexao->close();
    ?>
</body>

</html>