<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../css/tabelas.css">
    <title>Consulta de Produto no Estoque</title>
    <link rel="stylesheet" href="../css/tables.css">
</head>

<body style="background-image:url('../assets/background.jpeg');">

    <div class="container w-100" style="border: solid 1px #fff; background-color:#f55145;">
        <div class="row">
            <div class="col-12 d-flex justify-content-around mb-2">
                <h3 class="text-light fs-5 mt-2">Consulta do Produto no Estoque</h3>

                <a href="pdf_estoque.php" target="_blank" style="text-decoration: none;">
                    <button class="btn btn-outline-light mt-2 d-md-block d-none d-sm-none">Gerar Pdf</button>
                    <button class="btn btn-outline-light d-md-none mt-2 d-sm-block">PDF</button>
                </a>

                <a href="../estoque2.php">
                    <button class="btn btn-outline-light mt-2 ">Voltar</button>
                </a>
            </div>
        </div>

        <div class="row">
            <!--Table-->
            <table class="table-responsive-md table-bordered text-center" style="background-color: #f55145; color:#fff;">

                <thead>
                    <tr class="text-light">
                        <th>ID Estoque</th>
                        <th>Nome Produto</th>
                        <th>Quantidade</th>
                        <th>ID Compra</th>
                    </tr>
                </thead>

                <?php

                include "../model/connect.php";

                $nome = $_POST['nomeProduto'];

                //query select
                $sql = "SELECT * FROM tbl_estoque WHERE nome_produto_estoque = '$nome'";

                // buscar no banco de dados por meio da query select
                // para isso usamos o objeto de conexão e o método query()
                $result = $conexao->query($sql); // orientado a objetos utilizando obj $result

                // montar a lista na tabela
                // enquanto o fetch array possui registros ele retorna TRUE e quando ele termina, retorna FALSE
                // while ($linha = mysqli_fetch_array($result)) { // mysqli_fetch_array() procedural}
                while ($linha = $result->fetch_array()) {
                    $idEstoque = $linha['id_estoque'];
                    $nomeProd = $linha[1];
                    $qtdeProd = $linha[2];
                    $idCompra = $linha[3];


                    // montar a tabela
                    $html = <<<HTML
            <tbody>
                <tr>
                    <td>$idEstoque</td>
                    <td>$nomeProd</td>
                    <td>$qtdeProd</td>
                    <td>$idCompra</td>
                </tr>
HTML;
                    echo $html;
                } // fim do while

                // apagar o obj
                $result->close();

                // encerrar a conexão
                $conexao->close();
                ?>

            </table>
        </div>
    </div>
</body>