<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendas Administrador</title>
    <link rel="stylesheet" href="css/modals.css">
    <link rel="shortcut icon" type="imagex/png" href="assets/logo-cuted.jpeg">
</head>

<body>

    <?php
    session_start();
    ?>

    <?php
    //testar se o usuario está logado

    //verificar se existe uma sessão aberta no server
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    //proteger caso o usúario tente acessar a página do adm, e vice-versa
    if($_SESSION['tipo'] != 1){
        session_destroy();
        header("location:index.php");
    }

    // testar se o usuario está logado ou não
    if (isset($_SESSION['nome'])) {
    } else {
        // apagar a variavel de sessão
        unset($_SESSION['nome']);
        header("Location: index.php");
    }

    ?>

    <main>
        <header>
            <div class="container">
                <!--Container Icone e Texto-->
                <div class="row">
                    <!--Linha da Div-->
                    <div class="col">
                        <!--Coluna da Div-->
                        <!--Icone-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" fill="#fff" class="bi bi-cash-coin icon" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M11 15a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm5-4a5 5 0 1 1-10 0 5 5 0 0 1 10 0z" />
                            <path d="M9.438 11.944c.047.596.518 1.06 1.363 1.116v.44h.375v-.443c.875-.061 1.386-.529 1.386-1.207 0-.618-.39-.936-1.09-1.1l-.296-.07v-1.2c.376.043.614.248.671.532h.658c-.047-.575-.54-1.024-1.329-1.073V8.5h-.375v.45c-.747.073-1.255.522-1.255 1.158 0 .562.378.92 1.007 1.066l.248.061v1.272c-.384-.058-.639-.27-.696-.563h-.668zm1.36-1.354c-.369-.085-.569-.26-.569-.522 0-.294.216-.514.572-.578v1.1h-.003zm.432.746c.449.104.655.272.655.569 0 .339-.257.571-.709.614v-1.195l.054.012z" />
                            <path d="M1 0a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h4.083c.058-.344.145-.678.258-1H3a2 2 0 0 0-2-2V3a2 2 0 0 0 2-2h10a2 2 0 0 0 2 2v3.528c.38.34.717.728 1 1.154V1a1 1 0 0 0-1-1H1z" />
                            <path d="M9.998 5.083 10 5a2 2 0 1 0-3.132 1.65 5.982 5.982 0 0 1 3.13-1.567z" />
                        </svg>
                    </div>
                    <!--Fim Coluna da Div-->
                </div>
                <!--Fim Linha da Div-->

                <div class="row">
                    <!--Linha da Div-->
                    <div class="col">
                        <!--Coluna da Div-->

                        <h2 class="title">Controle de Vendas</h2>

                        <br>

                        <p class="text">Adicione as Vendas dos produtos para ter um melhor controle, no seu estoque digital.</p>

                        <p class="text">As vendas são adicionadas, pelo
                            nome do produto, sua quantidade, seu identificador no estoque, e a data na qual a venda foi realizada.</p>

                        <p class="text">As Vendas podem ser, adicionadas, consultadas, modificadas, e deletadas de
                            acordo
                            com
                            a necessidade.</p>
                    </div>
                </div>
                <!--Fim Coluna da Div-->

                <div class="row">
                    <div class="col">
                        <a href="main.php">
                            <svg style="margin-top: 25px; margin-right:10px;" xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="#fff" class="bi bi-x-lg" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M13.854 2.146a.5.5 0 0 1 0 .708l-11 11a.5.5 0 0 1-.708-.708l11-11a.5.5 0 0 1 .708 0Z" />
                                <path fill-rule="evenodd" d="M2.146 2.146a.5.5 0 0 0 0 .708l11 11a.5.5 0 0 0 .708-.708l-11-11a.5.5 0 0 0-.708 0Z" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <!--Fim Linha da Div-->
        </header>

        <section>
            <!--CARDS-->
            <a href="#" onclick="Modal.openAdicionar()">
                <!--Link Modal Adicionar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Adicionar-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-plus-circle-fill" viewBox="0 0 16 16">
                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z" />
                        </svg>
                    </div>
                    <!--Fim do Div da Imagem-->

                    <div class="card-title-content">
                        <!--Div Título-->
                        <p class="card-title">Adicionar</p>
                    </div>
                    <!--Fim Título-->
                </div>
                <!--Fim do Card Adicionar-->
            </a>
            <!--Fim Link Modal Adicionar-->

            <a href="#" onclick="Modal.openConsultar()">
                <!--Link Modal Consultar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Consultar-->
                    <div class="img-content">
                        <!--Div da Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-eye-fill" viewBox="0 0 16 16">
                            <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z" />
                            <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z" />
                        </svg>
                        <!--Fim Div da Imagem-->
                    </div>

                    <div class="card-title-content">
                        <!--Div Título Consultar-->
                        <p class="card-title">Consultar</p>
                    </div>
                    <!--Fim Div Título Consultar-->
                </div>
                <!--Fim do Card Consultar-->
            </a>
            <!--Fim Link Modal Consultar-->

            <a href="#" onclick="Modal.openEditar()">
                <!--Link Modal Editar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Editar-->
                    <div class="img-content">
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-pencil-square" viewBox="0 0 16 16">
                            <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                        </svg>
                    </div>
                    <div class="card-title-content">
                        <!--Início do Título Editar-->
                        <p class="card-title">Editar</p>
                    </div>
                    <!--Fim do Título Editar-->
                </div>
                <!--Fim do Card Editar-->
            </a>
            <!--Fim Link Modal Editar-->

            <a href="#" onclick="Modal.openDeletar()">
                <!--Link Modal Deletar-->
                <div class="card m-2 border-0">
                    <!--Início do Card Deletar-->
                    <div class="img-content">
                        <!--Div Imagem-->
                        <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="#fff" class="bi bi-trash-fill" viewBox="0 0 16 16">
                            <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z" />
                        </svg>
                    </div>
                    <!--Fim Div Imagem-->

                    <div class="card-title-content">
                        <!--Início do Título Deletar-->
                        <p class="card-title">Deletar</p>
                    </div>
                    <!--Fim do Título Deletar-->
                </div>
                <!--Fim do Card Deletar-->
            </a><!-- Link Modal Deletar-->

            <!--CARDS-->
        </section>
    </main>

    <div class="modal-overlay">
        <!--Container do Modal Adicionar-->
        <div class="modal">
            <!--Modal-->
            <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Nova Venda</h2>
            <!--Titulo Modal-->
            <form method="POST" action="vendas/adicionar_venda.php" id="form">
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="nomeProdutoVendas" id="nomeProdutoVendas" placeholder="Nome do Produto Vendido" required>
                </div>

                <div class="input-group">
                    <!--Campo Quantidade-->
                    <input type="text" name="quantidadeVendas" id="quantidadeVendas" placeholder="Quantidade do Produto Vendido" required>
                </div>

                <div class="input-group">
                    <!--Campo ID Estoque-->
                    <input type="number" name="idEstoque" id="idEstoque" placeholder="ID do Produto no Estoque" minlength="1" required>
                </div>

                <div class="input-group">
                    <!--Campo Data-->
                    <input type="date" name="data" id="data" required>
                </div>

                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeAdicionar()">Cancelar</a>
                    <button type="submit" class="submit">Cadastrar</button>
                </div>
            </form>
            <!--Fim Formulário Modal-->
        </div>
        <!--Fim Corpo Modal-->
    </div>
    <!--Fim Container Modal Adicionar-->

    <div class="modal-overlay modal-overlay-consultar">
        <!--Container do Modal Consultar-->
        <div class="modal">
            <!--Modal-->
            <div class="modal-title">
                <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Consultar Venda do Produto</h2>
                <br>
                <a href="vendas/consultarTodas_vendas.php" style="color:#f55145; width:48%; font-size:14px; margin:5px 0 0 15px;">Consultar todas as Vendas</a>
            </div>
            <!--Titulo Modal-->
            <form method="POST" action="vendas/consultar_venda.php" id="form">
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="nomeProduto" id="nomeProduto" placeholder="Nome do Produto" required>
                </div>

                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeConsultar()">Cancelar</a>
                    <button type="submit" class="submit">Consultar</button>
                </div>
            </form>
            <!--Fim Formulário Modal-->
        </div>
        <!--Fim Corpo Modal-->
    </div>
    <!--Fim Container Modal Consultar-->

    <div class="modal-overlay modal-overlay-editar">
        <!--Container do Modal Editar-->
        <div class="modal">
            <!--Modal-->
            <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Editar Venda do Produto</h2>
            <!--Titulo Modal-->
            <form method="POST" action="vendas/editar_venda.php" id="form">

                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="idVenda" id="nomeProduto" placeholder="ID Venda" required>
                </div>
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="nomeProduto" id="nomeProduto" placeholder="Novo Nome do Produto Vendido" required>
                </div>

                <div class="input-group">
                    <!--Campo Quantidade-->
                    <input type="text" name="quantidadeVendas" id="quantidadeVendas" placeholder="Nova Quantidade do Produto Vendido" required>
                </div>
                
                <div class="input-group">
                    <!--Campo ID Estoque-->
                    <input type="number" name="idEstoque" id="idEstoque" placeholder="ID do Produto no Estoque" minlength="1" required>
                </div>

                <div class="input-group">
                    <!--Campo Data-->
                    <input type="date" name="data" id="data" required>
                </div>
                
                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeEditar()">Cancelar</a>
                    <button type="submit" class="submit">Editar</button>
                </div>
                <!--Fim Formulário Modal Editar -->
            </form>
        </div>
        <!--Fim Corpo Modal Editar-->
    </div>
    <!--Fim Container Modal Editar-->

    <div class="modal-overlay modal-overlay-deletar">
        <!--Container do Modal Deletar-->
        <div class="modal">
            <!--Modal-->
            <h2 style="color:#f55145; font-family: fantasy, sans-serif;">Deletar Venda do Produto</h2>
            <!--Titulo Modal-->
            <form method="POST" action="vendas/excluir_venda.php" id="form">
                <!--Formulário Modal-->
                <div class="input-group">
                    <!--Campo Produto-->
                    <input type="text" name="nome_produto" id="nomeProduto" placeholder="Nome do Produto" required>
                </div>

                <div class="input-group actions">
                    <a href="#" class="cancel" onclick="Modal.closeDeletar()">Cancelar</a>
                    <button type="submit" class="submit">Deletar</button>
                </div>
            </form>
            <!--Fim Formulário Modal Deletar-->
        </div>
        <!--Fim Corpo Modal-->
    </div>
    <!--Fim Container Modal Consultar-->

    <footer>
        <p>System Store ©</p>
    </footer>

    <script>
        Modal = {
            openAdicionar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay")
                    .classList.add('active')

            },
            closeAdicionar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay")
                    .classList.remove('active')
            },

            openConsultar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay-consultar")
                    .classList.add('active')

            },
            closeConsultar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay-consultar")
                    .classList.remove('active')
            },

            openEditar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay-editar")
                    .classList.add('active')

            },
            closeEditar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay-editar")
                    .classList.remove('active')
            },
            openDeletar() {
                //Abrir Modal
                //Adicionar a class active do modal
                document.querySelector(".modal-overlay-deletar")
                    .classList.add('active')

            },
            closeDeletar() {
                //Fechar o Modal
                //Remover a classe active do modal
                document.querySelector(".modal-overlay-deletar")
                    .classList.remove('active')
            }
        }
    </script>
</body>

</html>